<?php


function theme_setup(){

    load_theme_textdomain('blog', get_template_directory() . '/languages');

    register_nav_menus(array(
        'primary-menu' => __('Primary Menu', 'blog')
    ));

    /** automatic feed link*/
    add_theme_support( 'automatic-feed-links' );

    /** tag-title **/
    add_theme_support( 'title-tag' );

    /** post formats */
    $post_formats = array('aside','image','gallery','video','audio','link','quote','status');
    add_theme_support( 'post-formats', $post_formats);

    /** post thumbnail **/
    add_theme_support( 'post-thumbnails' );

    /** HTML5 support **/
    add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );

    /** refresh widgest **/
    add_theme_support( 'customize-selective-refresh-widgets' );

    /** custom background **/
    $bg_defaults = array(
        'default-image'          => '',
        'default-preset'         => 'default',
        'default-size'           => 'cover',
        'default-repeat'         => 'no-repeat',
        'default-attachment'     => 'scroll',
    );
    add_theme_support( 'custom-background', $bg_defaults );

    /** custom header **/
    $header_defaults = array(
        'default-image'          => '',
        'width'                  => 300,
        'height'                 => 60,
        'flex-height'            => true,
        'flex-width'             => true,
        'default-text-color'     => '',
        'header-text'            => true,
        'uploads'                => true,
    );
    add_theme_support( 'custom-header', $header_defaults );

    /** custom log **/
    add_theme_support( 'custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array( 'site-title', 'site-description' ),
    ) );

        
    /**
     * Classing Widget Restore
     */
    remove_theme_support( 'widgets-block-editor' );
    /**
     * Classing Widget Restore
     */

}
add_action( 'after_setup_theme', 'theme_setup' );


    // Css And Js Files Linking 
function blog_bootstrapping() {
    
    // css
    wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css');
    wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css');
    wp_enqueue_style( 'owl', get_template_directory_uri() . '/css/owl.css');
    wp_enqueue_style( 'main', get_template_directory_uri() . '/css/style.css');
    wp_enqueue_style( 'responsive', get_template_directory_uri() . '/css/responsive.css');
    wp_enqueue_style( 'style-belfast', get_stylesheet_uri() );
    // css

    // js
    wp_enqueue_script( 'bootstrap-js', get_template_directory_uri().'/js/bootstrap.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'owl-carousel', get_template_directory_uri().'/js/owl.carousel.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'wow-js', get_template_directory_uri().'/js/wow.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'script-js', get_template_directory_uri().'/js/script.js', array('jquery'), '1.0.0', true );
    // js
   
        
}
add_action( 'wp_enqueue_scripts', 'blog_bootstrapping' );

function wpdocs_custom_excerpt_length( $length ) {
	return 20;
}
add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length', 999 );



function belfast_widget() {
	register_sidebar( array(
		'name'          => __( 'Main Sidebar', 'blog' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'blog' ),
		'before_widget' => '<li id="%1$s" class="widget %2$s">',
		'after_widget'  => '</li>',
		'before_title'  => '<div class="sidebar-title">',
		'after_title'   => '</div>',
	) );
}
add_action( 'widgets_init', 'belfast_widget' );

// custom Author Box widget
class Author_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'author-box',  // Base ID
			__('Author Box', 'blog')   // Name
		);
		add_action( 'widgets_init', function() {
			register_widget( 'Author_Widget' );
		});
	}

	public $args = array(
		'before_widget' => '<div class="widget-wrap">',
		'after_widget'  => '</div></div>',
	);

	public function widget( $args, $instance ) {

        $widget_id = 'widget_' . $args['widget_id']; 
        $author_image = get_field('author_image', $widget_id);
        $author_name = get_field('author_name', $widget_id);
        $author_description = get_field('author_description', $widget_id);
        $social_icons = get_field('social_icons', $widget_id);

        // echo '<pre>';
        // print_r($social_icons);
        // echo '</pre>';

		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}
		?>

            <div class="sidebar-about centred">
                <figure class="img-box"><img src="<?php echo $author_image;?>" alt=""></figure>
                <h5 class="name"><?php echo $author_name;?></h5>
                <div class="text"><p><?php echo $author_description;?></p></div>
                <ul class="social-link">
                    <?php
                        foreach($social_icons as $social_icon){
                    ?>
                    <li><a href="<?php echo $social_icon['url']?>"><i class="<?php echo $social_icon['icons']?>"></i></a></li>
                    <?php
                    }
                    ?>
                </ul>
            </div>
        <?php
	}

	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'blog' );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'blog' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance          = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		return $instance;
	}
}
$author_widget = new Author_Widget();

// custom Author Box widget

// custom Recent Post widget
class Recent_Posts_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'recent-posts',  // Base ID
			__('Recent Posts', 'blog')   // Name
		);
		add_action( 'widgets_init', function() {
			register_widget( 'Recent_Posts_Widget' );
		});
	}

	public $args = array(
		'before_widget' => '<div class="widget-wrap">',
		'after_widget'  => '</div></div>',
	);

	public function widget( $args, $instance ) {

        $widget_id = 'widget_' . $args['widget_id']; 
        $post_to_show = get_field('post_to_show', $widget_id);
        $order_by = get_field('order_by', $widget_id);
        $show_date = get_field('show_date', $widget_id);

        // echo '<pre>';
        // print_r($social_icons);
        // echo '</pre>';

		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}
		?>
            <!-- custom html here -->
            <div class="sidebar-post">
                <?php
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => $post_to_show,
                        'order' => $order_by
                    );
                    $query = new WP_Query($args);
                    while( $query -> have_posts( )){
                        $query -> the_post( );
                ?>
                <div class="single-post">
                    <div class="img-box"><a href="<?php the_permalink()?>"><figure><img src="<?php the_post_thumbnail_url() ;?>" alt=""></figure></a></div>
                    <h6><a href="<?php the_permalink()?>"><?php the_title()?></a></h6>
                    <?php
                        if($show_date == true){
                    ?>
                        <div class="text"><?php echo get_the_date()?></div>
                    <?php
                        }
                    ?>
                    
                </div>
                <?php
                }
                ?>
            </div>
            <!-- custom html here -->
            
        <?php
	}

	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'blog' );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'blog' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance          = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		return $instance;
	}
}
$recent_posts_widget = new Recent_Posts_Widget();
// custom Recent Post widget

// custom Newslater Post widget
class Newslater_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'newslater',  // Base ID
			__('Newslater Widget', 'blog')   // Name
		);
		add_action( 'widgets_init', function() {
			register_widget( 'Newslater_Widget' );
		});
	}

	public $args = array(
		'before_widget' => '<div class="widget-wrap">',
		'after_widget'  => '</div></div>',
	);

	public function widget( $args, $instance ) {

        $widget_id = 'widget_' . $args['widget_id']; 
        $newslater_title = get_field('newslater_title', $widget_id);
        $description = get_field('description', $widget_id);


        // echo '<pre>';
        // print_r($social_icons);
        // echo '</pre>';

		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}
		?>
            <!-- custom html here -->
            <div class="sidebar-newsletter centred">
                <div class="title"><i class="fa fa-envelope-o"></i>&nbsp;&nbsp;<?php echo $newslater_title ?></div>
                <div class="text"><?php echo $description ?></div>
                <?php echo do_shortcode('[contact-form-7 id="101" title="Newslater Widget"]')?>
            </div>
            <!-- custom html here -->
            
        <?php
	}

	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'blog' );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'blog' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance          = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		return $instance;
	}
}
$newslater_widget = new Newslater_Widget();
// custom Newslater widget


// custom Category widget
class Category_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'Belfast_Category',  // Base ID
			__('Belfast Category', 'blog')   // Name
		);
		add_action( 'widgets_init', function() {
			register_widget( 'Category_Widget' );
		});
	}

	public $args = array(
		'before_widget' => '<div class="widget-wrap">',
		'after_widget'  => '</div></div>',
	);

	public function widget( $args, $instance ) {

        $widget_id = 'widget_' . $args['widget_id']; 
        // $newslater_title = get_field('newslater_title', $widget_id);

        // echo '<pre>';
        // print_r($social_icons);
        // echo '</pre>';

		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}
		?>
            <!-- custom html here -->
            <div class="sidebar-categories">
                <ul class="categories-list"> 
                    <?php
                        $cats = get_categories();
                        foreach($cats as $cat){
                    ?>
                        <li><a href="#"><?php echo $cat->cat_name?><span>(<?php echo $cat->count?>)</span></a></li>
                    <?php      
                        }
                    ?>
                    
                </ul>
            </div>
            <!-- custom html here -->
            
        <?php
	}

	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'blog' );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'blog' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance          = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		return $instance;
	}
}
$category_widget = new Category_Widget();
// custom Category widget













// function add_additional_class_on_li($classes, $item, $args) {
//     if(isset($args->add_li_class)) {
//         $classes[] = $args->add_li_class;
//     }
//     return $classes;
// }
// add_filter('nav_menu_css_class', 'add_additional_class_on_li', 1, 3);

// function add_menu_link_class( $atts, $item, $args ) {
//   if (property_exists($args, 'link_class')) {
//     $atts['class'] = $args->link_class;
//   }
//   return $atts;
// }
// add_filter( 'nav_menu_link_attributes', 'add_menu_link_class', 1, 3 );



    